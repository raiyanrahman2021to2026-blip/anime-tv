package com.animetv.home

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Draws all four StandBy styles on a plain Canvas. No libraries. */
class ClockView(context: Context) : View(context) {

    private var cfg = ClockPrefs.read(context)
    private val handler = Handler(Looper.getMainLooper())
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thin = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)
    private var ticks = 0
    private var spot = 0
    private var dx = 0f
    private var dy = 0f
    private val spots = arrayOf(
        floatArrayOf(0f, 0f), floatArrayOf(14f, -10f), floatArrayOf(-12f, 12f),
        floatArrayOf(10f, 14f), floatArrayOf(-14f, -8f)
    )

    private val tick = object : Runnable {
        override fun run() {
            ticks++
            if (ticks % 60 == 0) {            // drift a few pixels each minute: no burn-in
                spot = (spot + 1) % spots.size
                dx = spots[spot][0]
                dy = spots[spot][1]
            }
            invalidate()
            handler.postDelayed(this, 1000L - System.currentTimeMillis() % 1000L)
        }
    }

    fun reload() {
        cfg = ClockPrefs.read(context)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- helpers

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        tf: Typeface, align: Paint.Align = Paint.Align.CENTER, alpha: Int = 255, spacing: Float = 0f
    ) {
        paint.style = Paint.Style.FILL
        paint.textSize = size
        paint.color = color
        paint.alpha = alpha
        paint.typeface = tf
        paint.textAlign = align
        paint.letterSpacing = spacing
        c.drawText(s, x, y, paint)
        paint.letterSpacing = 0f
        paint.alpha = 255
    }

    /** Time drawn with fixed-width digit cells, so the clock never jitters as digits change. */
    private fun timeWidth(s: String, size: Float, tf: Typeface): Float {
        paint.textSize = size; paint.typeface = tf
        val cell = paint.measureText("0")
        val colon = paint.measureText(":") * 1.1f
        var w = 0f
        for (ch in s) w += if (ch == ':') colon else cell
        return w
    }

    private fun drawTime(
        c: Canvas, s: String, left: Float, baseY: Float, size: Float, color: Int,
        tf: Typeface, sec: Int
    ) {
        paint.textSize = size; paint.typeface = tf
        val cell = paint.measureText("0")
        val colon = paint.measureText(":") * 1.1f
        var x = left
        for (ch in s) {
            val cw = if (ch == ':') colon else cell
            val a = if (ch == ':' && sec % 2 == 1) 90 else 255
            text(c, ch.toString(), x + cw / 2f, baseY, size, color, tf, Paint.Align.CENTER, a)
            x += cw
        }
    }

    // ---------------------------------------------------------------- draw

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cal = Calendar.getInstance()
        var hour = cal.get(Calendar.HOUR_OF_DAY)
        if (!cfg.h24) { hour %= 12; if (hour == 0) hour = 12 }
        val hs = if (cfg.h24) "%02d".format(hour) else hour.toString()
        val ms = "%02d".format(cal.get(Calendar.MINUTE))
        val sec = cal.get(Calendar.SECOND)
        val accent = if (cfg.night) ClockPrefs.NIGHT_RED else ClockPrefs.COLORS[cfg.color]
        val ink = if (cfg.night) ClockPrefs.NIGHT_RED else 0xFFF4F5F8.toInt()
        val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(cal.time).uppercase()

        canvas.save()
        canvas.translate(dx * w / 1920f, dy * w / 1920f)
        when (cfg.style) {
            0 -> digital(canvas, w, h, hs, ms, sec, date, accent, ink)
            1 -> analog(canvas, w, h, cal, accent, ink)
            2 -> split(canvas, w, h, hs, ms, sec, date, cal, accent, ink)
            else -> stack(canvas, w, h, hs, ms, date, accent, ink)
        }
        canvas.restore()
    }

    private fun digital(c: Canvas, w: Float, h: Float, hs: String, ms: String, sec: Int,
                        date: String, accent: Int, ink: Int) {
        text(c, date, w / 2f, h * 0.30f, w * 0.03f, ink, light, alpha = 170, spacing = 0.08f)
        val s = "$hs:$ms"
        val size = w * 0.21f
        val tw = timeWidth(s, size, thin)
        drawTime(c, s, w / 2f - tw / 2f, h * 0.62f, size, accent, thin, sec)
        if (cfg.seconds) text(c, "%02d".format(sec), w / 2f, h * 0.76f, w * 0.04f, ink, light, alpha = 150)
    }

    private fun analog(c: Canvas, w: Float, h: Float, cal: Calendar, accent: Int, ink: Int) {
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) * 0.44f
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 60) {
            val big = i % 5 == 0
            val a = Math.toRadians(i * 6.0)
            val r1 = if (big) r * 0.90f else r * 0.95f
            paint.color = if (big) ink else 0xFF5B6172.toInt()
            paint.strokeWidth = if (big) r * 0.02f else r * 0.01f
            c.drawLine(cx + r1 * sin(a).toFloat(), cy - r1 * cos(a).toFloat(),
                cx + r * sin(a).toFloat(), cy - r * cos(a).toFloat(), paint)
        }
        for (n in intArrayOf(12, 3, 6, 9)) {
            val a = Math.toRadians((n % 12) * 30.0)
            text(c, n.toString(), cx + r * 0.72f * sin(a).toFloat(),
                cy - r * 0.72f * cos(a).toFloat() + r * 0.085f, r * 0.17f, ink, light)
        }
        val s = cal.get(Calendar.SECOND)
        val m = cal.get(Calendar.MINUTE) + s / 60f
        val hr = (cal.get(Calendar.HOUR_OF_DAY) % 12) + m / 60f
        hand(c, cx, cy, hr * 30f, r * 0.48f, r * 0.05f, ink)
        hand(c, cx, cy, m * 6f, r * 0.75f, r * 0.035f, ink)
        if (cfg.seconds) hand(c, cx, cy, s * 6f, r * 0.83f, r * 0.016f, accent)
        paint.style = Paint.Style.FILL
        paint.color = accent
        c.drawCircle(cx, cy, r * 0.045f, paint)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, sw: Float, color: Int) {
        val a = Math.toRadians(deg.toDouble())
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = sw
        paint.color = color
        c.drawLine(cx, cy, cx + len * sin(a).toFloat(), cy - len * cos(a).toFloat(), paint)
    }

    private fun split(c: Canvas, w: Float, h: Float, hs: String, ms: String, sec: Int,
                      date: String, cal: Calendar, accent: Int, ink: Int) {
        val s = "$hs:$ms"
        val size = w * 0.15f
        drawTime(c, s, w * 0.06f, h * 0.52f, size, accent, thin, sec)
        text(c, date, w * 0.07f, h * 0.63f, w * 0.024f, ink, light, Paint.Align.LEFT, 170, 0.08f)

        val x0 = w * 0.56f
        val cell = w * 0.37f / 7f
        val month = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time).uppercase()
        text(c, month, x0, h * 0.22f, w * 0.026f, accent, bold, Paint.Align.LEFT, spacing = 0.06f)
        val letters = arrayOf("M", "T", "W", "T", "F", "S", "S")
        val headY = h * 0.30f
        for (i in 0 until 7) text(c, letters[i], x0 + cell * (i + 0.5f), headY, cell * 0.42f, ink, light, alpha = 110)

        val first = Calendar.getInstance().apply {
            set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1)
        }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7     // Monday first
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = cal.get(Calendar.DAY_OF_MONTH)
        for (d in 1..days) {
            val idx = offset + d - 1
            val col = idx % 7
            val row = idx / 7
            val cx = x0 + cell * (col + 0.5f)
            val cy = headY + cell * 0.95f * (row + 1)
            if (d == today) {
                paint.style = Paint.Style.FILL
                paint.color = accent
                c.drawCircle(cx, cy - cell * 0.14f, cell * 0.42f, paint)
                text(c, d.toString(), cx, cy, cell * 0.42f, Color.BLACK, bold)
            } else {
                text(c, d.toString(), cx, cy, cell * 0.42f, ink, light, alpha = 190)
            }
        }
    }

    private fun stack(c: Canvas, w: Float, h: Float, hs: String, ms: String,
                      date: String, accent: Int, ink: Int) {
        val size = w * 0.27f
        val bw = maxOf(timeWidth(hs, size, bold), timeWidth(ms, size, bold))
        val left = w / 2f - bw / 2f
        drawTime(c, hs, left, h * 0.40f, size, accent, bold, 0)
        drawTime(c, ms, left, h * 0.40f + size * 0.80f, size, ink, bold, 0)
        text(c, date, left, h * 0.90f, w * 0.026f, ink, light, Paint.Align.LEFT, 160, 0.08f)
    }
}
