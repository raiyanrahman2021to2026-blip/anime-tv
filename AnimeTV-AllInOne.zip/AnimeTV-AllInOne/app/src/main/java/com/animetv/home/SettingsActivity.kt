package com.animetv.home

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** TV-friendly settings: live preview on top, D-pad buttons below. */
class SettingsActivity : Activity() {

    private lateinit var clock: ClockView
    private lateinit var bStyle: Button
    private lateinit var bColor: Button
    private lateinit var b24: Button
    private lateinit var bSec: Button
    private lateinit var bNight: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        clock = ClockView(this)
        root.addView(clock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row1 = row(); val row2 = row()
        bStyle = btn(row1) { upd { it.copy(style = (it.style + 1) % ClockPrefs.STYLES.size) } }
        bColor = btn(row1) { upd { it.copy(color = (it.color + 1) % ClockPrefs.COLORS.size, night = false) } }
        b24 = btn(row1) { upd { it.copy(h24 = !it.h24) } }
        bSec = btn(row2) { upd { it.copy(seconds = !it.seconds) } }
        bNight = btn(row2) { upd { it.copy(night = !it.night) } }
        btn(row2, "Open Screen saver settings") {
            try { startActivity(Intent(Settings.ACTION_DREAM_SETTINGS)) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        root.addView(row1); root.addView(row2)

        val hint = TextView(this).apply {
            text = "In TV Settings > Device Preferences > Screen saver, choose \"StandBy Clock\" and set When to start to 5 min."
            setTextColor(0xFF8B92A3.toInt()); textSize = 14f; gravity = Gravity.CENTER
            setPadding(24, 8, 24, 20)
        }
        root.addView(hint)
        setContentView(root)
        refresh()
        bStyle.requestFocus()
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(0, 8, 0, 8)
    }

    private fun btn(parent: LinearLayout, label: String = "", onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            isFocusable = true
            setOnClickListener { onClick() }
            parent.addView(this, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(12, 0, 12, 0)
            })
        }

    private fun upd(f: (Cfg) -> Cfg) {
        ClockPrefs.write(this, f(ClockPrefs.read(this)))
        refresh()
    }

    private fun refresh() {
        val c = ClockPrefs.read(this)
        bStyle.text = "Style: " + ClockPrefs.STYLES[c.style]
        bColor.text = "Colour: " + ClockPrefs.COLOR_NAMES[c.color]
        b24.text = "Format: " + if (c.h24) "24-hour" else "12-hour"
        bSec.text = "Seconds: " + if (c.seconds) "On" else "Off"
        bNight.text = "Night (red): " + if (c.night) "On" else "Off"
        clock.reload()
    }
}
