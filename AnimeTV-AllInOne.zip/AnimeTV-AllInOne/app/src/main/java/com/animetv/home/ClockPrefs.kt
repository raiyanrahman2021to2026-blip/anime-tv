package com.animetv.home

import android.content.Context

data class Cfg(
    val style: Int = 0,        // 0 digital, 1 analog, 2 clock+calendar, 3 bold stack
    val color: Int = 0,        // index into ClockPrefs.COLORS
    val h24: Boolean = false,
    val seconds: Boolean = true,
    val night: Boolean = false // red-only mode
)

object ClockPrefs {
    val STYLES = arrayOf("Digital", "Analog", "Clock + calendar", "Bold stack")
    val COLOR_NAMES = arrayOf("Amber", "Coral", "Mint", "Sky", "Violet", "Pink", "White")
    val COLORS = intArrayOf(
        0xFFFF9F0A.toInt(), 0xFFFF6B6B.toInt(), 0xFF32D6A0.toInt(), 0xFF4CB8FF.toInt(),
        0xFFA78BFA.toInt(), 0xFFFF5FA2.toInt(), 0xFFF4F5F8.toInt()
    )
    const val NIGHT_RED = 0xFFFF453A.toInt()

    private const val FILE = "standby"

    fun read(c: Context): Cfg {
        val p = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return Cfg(
            style = p.getInt("style", 0).coerceIn(0, STYLES.size - 1),
            color = p.getInt("color", 0).coerceIn(0, COLORS.size - 1),
            h24 = p.getBoolean("h24", false),
            seconds = p.getBoolean("seconds", true),
            night = p.getBoolean("night", false)
        )
    }

    fun write(c: Context, cfg: Cfg) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt("style", cfg.style).putInt("color", cfg.color)
            .putBoolean("h24", cfg.h24).putBoolean("seconds", cfg.seconds)
            .putBoolean("night", cfg.night).apply()
    }
}
