ANIME TV - ALL IN ONE
=====================
Is zip me kya hai
- app/        : Anime Home + StandBy Clock screensaver, ek hi APK (Gradle project)
- theme/anime-neon : neon-night wallpapers + simple-clean ki halki settings ka merged CleanYourTV theme
- launcher/   : cleanyourtv-clean-launcher.apk (aapka diya hua, com.gathin.tvhome)
- theme/*-original.json : purani neon-night / simple-clean config (backup)

STEP 1: APK banao (GitHub, ~5 minute) - bilkul StandBy wale tareeke se
1. github.com par naya repo banao (Public), naam: anime-tv
2. Is zip ko extract karke app/ launcher/ theme/ .github/ aur baaki sab files repo me upload karo.
   (.github hidden ho to: Add file > Create new file > .github/workflows/build.yml,
    aur app/src/main/res/xml/module_card.xml jaisi files bhi dhyan se upload karo.)
3. Actions tab > Build APK > hara tick > Artifacts > AnimeTVHome-apk > download > extract.
   Aapko app-debug.apk milegi.

STEP 2: TV par install
1. launcher/cleanyourtv-clean-launcher.apk ko pehle install karo (agar pehle se nahi hai) aur Home chuno.
2. app-debug.apk ko "Send Files to TV" se bhejo aur install karo.
3. "Anime Home" app row me dikhega. CleanYourTV launcher ek bar poochega "Show card?" - Show chuno.
   Iske baad Anime Home launcher ke dock me card ban jata hai.
4. Anime Home me "Clock screensaver" button se StandBy Clock ki settings khulti hain.
   TV Settings > Device Preferences > Screen saver > "StandBy Clock" chuno.

STEP 3: Theme lagao (cleanyourtv-main wala tools/theme.sh, PC ya Termux)
    TV_HOST=<TV_IP> tools/theme.sh /path/to/theme/anime-neon
Wapas purana look: TV_HOST=<TV_IP> tools/theme.sh --reset
Atakta hai to config.json me "advanced_effects": false pehle se hai.

NOTE: Ye project maine yahan compile nahi kiya (is chat me Android build tools nahi hain).
GitHub build me error aaye to error ka text mujhe bhej dena.
